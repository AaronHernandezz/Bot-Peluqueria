import os
import datetime as dt
from zoneinfo import ZoneInfo
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar.events"]
TZ = ZoneInfo("Europe/Madrid")


def get_calendar_service():
    creds = None

    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())

    return build("calendar", "v3", credentials=creds)


def parse_datetime(fecha_str, hora_str):
    naive = dt.datetime.strptime(f"{fecha_str} {hora_str}", "%Y-%m-%d %H:%M")
    return naive.replace(tzinfo=TZ)


def hueco_disponible(fecha_str, hora_str, duracion_min=30):
    service = get_calendar_service()

    inicio_dt = parse_datetime(fecha_str, hora_str)
    fin_dt = inicio_dt + dt.timedelta(minutes=duracion_min)

    eventos = service.events().list(
        calendarId="primary",
        timeMin=inicio_dt.isoformat(),
        timeMax=fin_dt.isoformat(),
        singleEvents=True,
        orderBy="startTime",
    ).execute()

    items = eventos.get("items", [])
    return len(items) == 0


def crear_cita_calendar(nombre, servicio, telefono, fecha_str, hora_str, duracion_min=30):
    service = get_calendar_service()

    inicio_dt = parse_datetime(fecha_str, hora_str)
    fin_dt = inicio_dt + dt.timedelta(minutes=duracion_min)

    evento = {
        "summary": f"{servicio} - {nombre}",
        "description": f"Cliente: {nombre}\nTeléfono: {telefono}\nServicio: {servicio}",
        "start": {
            "dateTime": inicio_dt.isoformat(),
            "timeZone": "Europe/Madrid",
        },
        "end": {
            "dateTime": fin_dt.isoformat(),
            "timeZone": "Europe/Madrid",
        },
    }

    creado = service.events().insert(calendarId="primary", body=evento).execute()
    return creado.get("htmlLink")