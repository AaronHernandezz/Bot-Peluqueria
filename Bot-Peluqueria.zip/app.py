import os
import json
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters
from openai import OpenAI
from calendar_utils import crear_cita_calendar, hueco_disponible

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=OPENAI_API_KEY)

# =========================
# CARGAR DATOS
# =========================
with open("services.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

servicios = datos["servicios"]
horario = datos["horario"]

SERVICIOS_VALIDOS = [s["nombre"].lower().strip() for s in servicios]

servicios_texto = "\n".join(
    [f"- {s['nombre']}: {s['precio']}" for s in servicios]
)

# =========================
# ESTADO
# =========================
def get_estado(context):
    if "reserva" not in context.user_data:
        context.user_data["reserva"] = {
            "nombre": None,
            "servicio": None,
            "fecha": None,
            "hora": None,
            "telefono": None,
            "pendiente_confirmacion": False,
        }

    if "reserva_activa" not in context.user_data:
        context.user_data["reserva_activa"] = False

    return context.user_data["reserva"]


def reset_estado(context):
    context.user_data["reserva"] = {
        "nombre": None,
        "servicio": None,
        "fecha": None,
        "hora": None,
        "telefono": None,
        "pendiente_confirmacion": False,
    }
    context.user_data["reserva_activa"] = False


# =========================
# IA INTERPRETACIÓN
# =========================
def interpretar(texto, estado):
    prompt = f"""
Analiza el mensaje de un cliente de peluquería.

Devuelve SOLO JSON:

{{
"intencion": "consulta_general" | "reservar_cita" | "confirmar" | "cancelar",
"nombre": null | string,
"servicio": null | string,
"fecha": null | string,
"hora": null | string,
"telefono": null | string
}}

Mensaje:
{texto}
"""

    r = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "Devuelve solo JSON válido"},
            {"role": "user", "content": prompt},
        ],
    )

    try:
        return json.loads(r.choices[0].message.content)
    except:
        return {"intencion": "consulta_general"}


# =========================
# IA CONSULTA (FIJADA)
# =========================
def responder_consulta(texto):
    prompt = f"""
Eres el asistente de 'Peluquería Aarón'.

INFORMACIÓN REAL (NO INVENTAR):

Servicios:
{servicios_texto}

Horario:
{horario}

REGLAS:
- NO inventes servicios
- NO inventes precios
- NO inventes horarios
- SOLO usa esta información
- Si no lo sabes, dilo

Responde claro, breve y natural.
"""

    r = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": texto},
        ],
    )

    return r.choices[0].message.content


# =========================
# VALIDACIONES
# =========================
def servicio_ok(s):
    return s and s.lower().strip() in SERVICIOS_VALIDOS


def fecha_ok(f):
    try:
        datetime.strptime(f, "%Y-%m-%d")
        return True
    except:
        return False


def hora_ok(h):
    try:
        datetime.strptime(h, "%H:%M")
        return True
    except:
        return False


def completa(e):
    return all([e["nombre"], e["servicio"], e["fecha"], e["hora"], e["telefono"]])


# =========================
# HANDLER
# =========================
async def manejar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto = update.message.text.strip()
    texto_lower = texto.lower().strip()

    estado = get_estado(context)

    # 🔥 FIX CLAVE: detectar SI / NO manualmente
    if texto_lower in ["si", "sí"]:
        intencion = "confirmar"
        data = {}
    elif texto_lower in ["no", "cancelar"]:
        intencion = "cancelar"
        data = {}
    else:
        data = interpretar(texto, estado)
        intencion = data.get("intencion", "consulta_general")

    # 🔥 ACTIVAR RESERVA
    if intencion == "reservar_cita":
        context.user_data["reserva_activa"] = True

    # 🔥 FORZAR FLUJO RESERVA
    if context.user_data["reserva_activa"] and not estado["pendiente_confirmacion"]:
        intencion = "reservar_cita"

    # =========================
    # CANCELAR
    # =========================
    if intencion == "cancelar":
        reset_estado(context)
        await update.message.reply_text("Reserva cancelada ❌")
        return

    # =========================
    # CONFIRMAR
    # =========================
    if intencion == "confirmar":
        if not estado["pendiente_confirmacion"]:
            await update.message.reply_text("No hay ninguna cita pendiente.")
            return

        if not hueco_disponible(estado["fecha"], estado["hora"]):
            await update.message.reply_text("Ese horario ya está ocupado ❌")
            return

        link = crear_cita_calendar(
            estado["nombre"],
            estado["servicio"],
            estado["telefono"],
            estado["fecha"],
            estado["hora"],
        )

        await update.message.reply_text(f"Cita confirmada ✅\n{link}")
        reset_estado(context)
        return

    # =========================
    # CONSULTA
    # =========================
    if intencion == "consulta_general" and not context.user_data["reserva_activa"]:
        r = responder_consulta(texto)
        await update.message.reply_text(r)
        return

    # =========================
    # RESERVA
    # =========================
    if intencion == "reservar_cita":

        for k in ["nombre", "servicio", "fecha", "hora", "telefono"]:
            if data.get(k):
                estado[k] = data[k]

        # VALIDACIONES
        if estado["servicio"] and not servicio_ok(estado["servicio"]):
            estado["servicio"] = None
            await update.message.reply_text(
                f"Servicio no válido.\nOpciones: {', '.join(SERVICIOS_VALIDOS)}"
            )
            return

        if estado["fecha"] and not fecha_ok(estado["fecha"]):
            estado["fecha"] = None
            await update.message.reply_text("Fecha: 2026-04-10")
            return

        if estado["hora"] and not hora_ok(estado["hora"]):
            estado["hora"] = None
            await update.message.reply_text("Hora: 16:30")
            return

        # COMPLETA → CONFIRMAR
        if completa(estado):
            estado["pendiente_confirmacion"] = True

            await update.message.reply_text(
                f"""Confirma tu cita:

Nombre: {estado['nombre']}
Servicio: {estado['servicio']}
Fecha: {estado['fecha']}
Hora: {estado['hora']}

Escribe SI para confirmar o NO para cancelar."""
            )
            return

        # PEDIR PASO A PASO
        if not estado["nombre"]:
            await update.message.reply_text("Dime tu nombre. Ej: Aarón")
            return

        if not estado["servicio"]:
            await update.message.reply_text(
                f"Servicio:\n{', '.join(SERVICIOS_VALIDOS)}"
            )
            return

        if not estado["fecha"]:
            await update.message.reply_text("Fecha (YYYY-MM-DD). Ej: 2026-04-10")
            return

        if not estado["hora"]:
            await update.message.reply_text("Hora (HH:MM). Ej: 16:30")
            return

        if not estado["telefono"]:
            await update.message.reply_text("Teléfono. Ej: 666123123")
            return

    # fallback
    r = responder_consulta(texto)
    await update.message.reply_text(r)


# =========================
# MAIN
# =========================
def main():
    print("Bot funcionando...")

    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, manejar))

    app.run_polling()


if __name__ == "__main__":
    main()