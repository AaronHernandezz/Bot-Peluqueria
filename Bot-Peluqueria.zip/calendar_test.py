import os.path
import datetime as dt
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar.events"]

def get_calendar_service():
    creds = None

    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)

        with open("token.json", "w", encoding="utf-8") as token:
            token.write(creds.to_json())

    return build("calendar", "v3", credentials=creds)

def main():
    service = get_calendar_service()

    inicio = dt.datetime(2026, 4, 10, 16, 0)
    fin = inicio + dt.timedelta(minutes=30)

    evento = {
        "summary": "Prueba cita peluquería",
        "description": "Cliente: Aarón\nServicio: Corte",
        "start": {
            "dateTime": inicio.isoformat(),
            "timeZone": "Europe/Madrid",
        },
        "end": {
            "dateTime": fin.isoformat(),
            "timeZone": "Europe/Madrid",
        },
    }

    creado = service.events().insert(calendarId="primary", body=evento).execute()
    print("Evento creado:", creado.get("htmlLink"))

if __name__ == "__main__":
    main()